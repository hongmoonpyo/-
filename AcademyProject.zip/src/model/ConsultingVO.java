package model;

import java.sql.Date;

public class ConsultingVO {
	private int cno;//����ȣ
private Date CDay; //��㳯��
private String CName; //�����
private String SName; //�л��̸�
private int SCode; //�л� ��ȣ
private String Contents; //����
public ConsultingVO() {
	super();
}

public ConsultingVO(int cno, Date cDay, String cName, String sName, int sCode, String contents) {
	super();
	this.cno = cno;
	CDay = cDay;
	CName = cName;
	SName = sName;
	SCode = sCode;
	Contents = contents;
}

public int getCno() {
	return cno;
}

public void setCno(int cno) {
	this.cno = cno;
}

public Date getCDay() {
	return CDay;
}
public void setCDay(Date cDay) {
	CDay = cDay;
}
public String getCName() {
	return CName;
}
public void setCName(String cName) {
	CName = cName;
}
public String getSName() {
	return SName;
}
public void setSName(String sName) {
	SName = sName;
}
public int getSCode() {
	return SCode;
}
public void setSCode(int sCode) {
	SCode = sCode;
}
public String getContents() {
	return Contents;
}
public void setContents(String contents) {
	Contents = contents;
}



}
