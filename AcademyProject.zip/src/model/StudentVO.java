package model;

import java.sql.Date;

public class StudentVO {
	private int scode;// �л� �ڵ�
	private String sname;// �̸�
	private int sbirthday;// ����
	private String sphon;// �ڵ�����ȣ
	private int Tuition;//������
	private String time;// �����ð�
	private String year; // �г�
	private Date date; // �������
	private int dan;// ��
	private int sclass;// ǰ
	private String add;// �ּ�
	private String pname;// �θ�� ����
	private String pphone;// �θ�� ��
	private String filename;// �̹���
	public StudentVO() {
		super();
	}
	
	public StudentVO(int scode, String sname, int sbirthday, String sphon, int tuition, String time, String year,
			int dan, int sclass, String add, String pname, String pphone, String filename) {
		super();
		this.scode = scode;
		this.sname = sname;
		this.sbirthday = sbirthday;
		this.sphon = sphon;
		Tuition = tuition;
		this.time = time;
		this.year = year;
		this.dan = dan;
		this.sclass = sclass;
		this.add = add;
		this.pname = pname;
		this.pphone = pphone;
		this.filename = filename;
	}

	public StudentVO(int scode, String sname, int sbirthday, String sphon, int tuition, String time, String year,
			Date date, int dan, int sclass, String add, String pname, String pphone, String filename) {
		super();
		this.scode = scode;
		this.sname = sname;
		this.sbirthday = sbirthday;
		this.sphon = sphon;
		Tuition = tuition;
		this.time = time;
		this.year = year;
		this.date = date;
		this.dan = dan;
		this.sclass = sclass;
		this.add = add;
		this.pname = pname;
		this.pphone = pphone;
		this.filename = filename;
	}

	public int getScode() {
		return scode;
	}

	public void setScode(int scode) {
		this.scode = scode;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public int getSbirthday() {
		return sbirthday;
	}

	public void setSbirthday(int sbirthday) {
		this.sbirthday = sbirthday;
	}

	public String getSphon() {
		return sphon;
	}

	public void setSphon(String sphon) {
		this.sphon = sphon;
	}

	public int getTuition() {
		return Tuition;
	}

	public void setTuition(int tuition) {
		Tuition = tuition;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getDan() {
		return dan;
	}

	public void setDan(int dan) {
		this.dan = dan;
	}

	public int getSclass() {
		return sclass;
	}

	public void setSclass(int sclass) {
		this.sclass = sclass;
	}

	public String getAdd() {
		return add;
	}

	public void setAdd(String add) {
		this.add = add;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getPphone() {
		return pphone;
	}

	public void setPphone(String pphone) {
		this.pphone = pphone;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}
	

}
