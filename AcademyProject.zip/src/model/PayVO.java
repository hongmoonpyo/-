package model;

import java.sql.Date;

public class PayVO {
	private int pcode; //
	private Date PDay; //��������
	private String SName; //�л��̸�
	private int SCode; //�л��ڵ�
	private String PBriefs; //�Ա�����
	private String PWay; //�Աݹ��
	private Date PClaim; //û������
	private int PDeposit; //�Աݾ�
	public PayVO() {
		super();
	}
	public PayVO(int pcode, Date pDay, String sName, int sCode, String pBriefs, String pWay, Date pClaim,
			int pDeposit) {
		super();
		this.pcode = pcode;
		PDay = pDay;
		SName = sName;
		SCode = sCode;
		PBriefs = pBriefs;
		PWay = pWay;
		PClaim = pClaim;
		PDeposit = pDeposit;
	}
	public int getPcode() {
		return pcode;
	}
	public void setPcode(int pcode) {
		this.pcode = pcode;
	}
	public Date getPDay() {
		return PDay;
	}
	public void setPDay(Date pDay) {
		PDay = pDay;
	}
	public String getSName() {
		return SName;
	}
	public void setSName(String sName) {
		SName = sName;
	}
	public int getSCode() {
		return SCode;
	}
	public void setSCode(int sCode) {
		SCode = sCode;
	}
	public String getPBriefs() {
		return PBriefs;
	}
	public void setPBriefs(String pBriefs) {
		PBriefs = pBriefs;
	}
	public String getPWay() {
		return PWay;
	}
	public void setPWay(String pWay) {
		PWay = pWay;
	}
	public Date getPClaim() {
		return PClaim;
	}
	public void setPClaim(Date pClaim) {
		PClaim = pClaim;
	}
	public int getPDeposit() {
		return PDeposit;
	}
	public void setPDeposit(int pDeposit) {
		PDeposit = pDeposit;
	}
	
	
	
}
