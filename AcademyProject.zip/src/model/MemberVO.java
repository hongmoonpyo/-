package model;

public class MemberVO {
	private String MPassword;
	private String ManagerName;
	private int ManagerPhon;
	private int AcademyCode;
	public MemberVO() {
		super();
	}
	public MemberVO(String mPassword, String managerName, int managerPhon, int academyCode) {
		super();
		MPassword = mPassword;
		ManagerName = managerName;
		ManagerPhon = managerPhon;
		AcademyCode = academyCode;
	}
	public MemberVO(String mPassword, int academyCode) {
		super();
		MPassword = mPassword;
		AcademyCode = academyCode;
	}
	public String getMPassword() {
		return MPassword;
	}
	public void setMPassword(String mPassword) {
		MPassword = mPassword;
	}
	public String getManagerName() {
		return ManagerName;
	}
	public void setManagerName(String managerName) {
		ManagerName = managerName;
	}
	public int getManagerPhon() {
		return ManagerPhon;
	}
	public void setManagerPhon(int managerPhon) {
		ManagerPhon = managerPhon;
	}
	public int getAcademyCode() {
		return AcademyCode;
	}
	public void setAcademyCode(int academyCode) {
		AcademyCode = academyCode;
	}
	
	
	
}