package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.MemberVO;

public class LoginController implements Initializable {
	@FXML
	private TextField txtAcademyCode;

	@FXML
	private TextField txtPassword;
	@FXML
	private Button btnLogin;
	@FXML
	private Button btnRegistrieren;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		btnLogin.setOnAction(event -> handlerBtnLoginAction(event));
		btnRegistrieren.setOnAction(event -> handlerBtnRegistrieren(event));

	}

	// ȸ������
	public void handlerBtnRegistrieren(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/MemberView.fxml"));
			Parent MemberView = (Parent) loader.load();
			Scene scane = new Scene(MemberView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("ȸ������");
			mainMtage.setScene(scane);
			Stage oldStage = (Stage) btnRegistrieren.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (IOException e) {
			System.out.println("����  " + e);
		}
	}

	// �α���
	public void handlerBtnLoginAction(ActionEvent event) {
		int SearchCode = 0;
		String SearchPassword = "";
		Alert alert;
		MemberVO mVo = new MemberVO();
		MemberDAO mDao = null;
		boolean searchResult = false;

		try {
			if (txtAcademyCode.getText().equals("") && txtPassword.getText().equals("")) {
				alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�α��� ����");
				alert.setHeaderText("���� ���Է�");
				alert.setContentText("���̵� �Ǵ� ��й�ȣ�� �Է��� �ּ���.");
				alert.showAndWait();
			} else {
				SearchPassword = txtPassword.getText();
				SearchCode = Integer.parseInt(txtAcademyCode.getText().trim());
				mDao = new MemberDAO();
				mVo = mDao.getMemberCheck(SearchPassword, SearchCode);
				if (!SearchPassword.equals(mVo.getMPassword()) || mVo.getAcademyCode() != SearchCode) {
					txtAcademyCode.clear();
					txtPassword.clear();
					alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("�α��� ����");
					alert.setHeaderText("�Է� ���� ����ġ");
					alert.setContentText("�Է��� ������ ��ġ���� �ʽ��ϴ�. \n �ٽ� �Է��Ͻÿ�.");
					alert.showAndWait();
				} else {
					try {
						searchResult = true;
						FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/MainView.fxml"));
						Parent mainView = (Parent) loader.load();
						Scene scane = new Scene(mainView);
						Stage mainMtage = new Stage();
						mainMtage.setTitle("ü���� ���� ���α׷�");
						mainMtage.setScene(scane);
						Stage oldStage = (Stage) btnLogin.getScene().getWindow();
						oldStage.close();
						mainMtage.show();
					} catch (IOException e) {
						System.out.println("����  " + e);
					}
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
		}

	}
}
