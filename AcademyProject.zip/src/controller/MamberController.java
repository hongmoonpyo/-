package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.MemberVO;

public class MamberController implements Initializable {
	@FXML
	private TextField txtMPassword;
	@FXML
	private TextField txtMName;
	@FXML
	private TextField txtMPhon;
	@FXML
	private TextField txtACode;
	@FXML
	private Button btnOk;
	@FXML
	private Button btnCancel;

	MemberVO member = new MemberVO();
	ObservableList<MemberVO> data = FXCollections.observableArrayList();

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		btnOk.setOnAction(event -> {
			try {
				data.removeAll(data);
				MemberVO mvo = null;
				MemberDAO mdao = null;

				if (event.getSource().equals(btnOk)) {
					mvo = new MemberVO(
							txtMPassword.getText(), txtMName.getText(), Integer.parseInt(txtMPhon.getText().trim()),
							Integer.parseInt(txtACode.getText().trim()));
					mdao = new MemberDAO();
					mdao.getMemberRegiste(mvo);
					
					if(mdao != null) {
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("ȸ������");
						alert.setHeaderText("����");
						alert.setContentText("�α��� ���ּ���.");
						alert.showAndWait();
						
						txtACode.setEditable(true);
						txtMName.setEditable(true);
						txtMPassword.setEditable(true);
						txtMPhon.setEditable(true);
						
						try {
							FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/LoginView.fxml"));
							Parent LoginView = (Parent) loader.load();
							Scene scane = new Scene(LoginView);
							Stage mainMtage = new Stage();
							mainMtage.setTitle("�α���");
							mainMtage.setScene(scane);
							Stage oldStage = (Stage) btnCancel.getScene().getWindow();
							oldStage.close();
							mainMtage.show();
						} catch (IOException e) {
							System.out.println(e);
						}
						
					}
				}
			} catch (Exception e) {
				Alert alert= new Alert(AlertType.WARNING);
				alert.setTitle("ȸ������ ����");
				alert.setHeaderText("ȸ������ ������ ��Ȯ�� �Է��Ͻÿ�");
				alert.setContentText("�ٽ� �Է��� �ּ���.");
				alert.showAndWait();
			}
		});
		btnCancel.setOnAction(event -> handlerBtnCancel(event));

	}

	public void handlerBtnCancel(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/LoginView.fxml"));
			Parent LoginView = (Parent) loader.load();
			Scene scane = new Scene(LoginView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("�α���");
			mainMtage.setScene(scane);
			Stage oldStage = (Stage) btnCancel.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (IOException e) {
			System.out.println(e);
		}
	}

}
