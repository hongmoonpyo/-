package controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Date;
import java.text.DecimalFormat;
import java.text.ParsePosition;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import model.StudentVO;

public class StudentController implements Initializable {
	@FXML
	private TableView<StudentVO> tableStudent = new TableView<>();
	@FXML
	private ImageView imageStudent;
	@FXML
	private Button btnImageFile;
	@FXML
	private TextField txtSCode;
	@FXML
	private TextField txtSName;
	@FXML
	private TextField txtSBirthday;
	@FXML
	private TextField txtSPhon;
	@FXML
	private ComboBox<String> cbSTime;
	@FXML
	private ComboBox<String> cbSYear;
	@FXML
	private DatePicker dpDate;
	@FXML
	private TextField txtDan;
	@FXML
	private TextField txtClass;
	@FXML
	private TextField txtTuition;
	@FXML
	private TextField txtAdd;
	@FXML
	private TextField txtPName;
	@FXML
	private TextField txtPPhone;
	@FXML
	private TextField txtSearchName;
	@FXML
	private Button btnSearch;
	@FXML
	private Button btnReset;
	@FXML
	private Button btnEnrollment;
	@FXML
	private Button btnModifed;
	@FXML
	private Button btnExit;
	@FXML
	private Button btnDelete;
	@FXML
	private Button btnTotalList;

	ObservableList<StudentVO> data = FXCollections.observableArrayList();
	ObservableList<StudentVO> selectStudent = null; // ���̺����� ������ ���� ����
	int selectedIndex; // ���̺����� ������ �л��� �ε��� ����
	private Stage primaryStage; //�̹��� ����â
	String selectFileName = "";// �̹��� ���ϸ�
	String localUrl = "";// �̹��� ���� ���
	Image locallmage;

	int scode; // ������ ���̺����� ������ �л��� ��ȣ ����
	
	File selectedFile = null;
	// �̹��� ó��
	// �̹��� ������ ������ �Ű������� ���� ��ü ����
	private File dirSave = new File("C:/images");
	// �̹��� �ҷ��� ������ ������ ���� ��ü ����
	private File file = null;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		btnModifed.setDisable(true);
		btnTotalList.setDisable(true);
		btnDelete.setDisable(true);
		btnReset.setDisable(true);
		
		// �޺� �� ����
		cbSTime.setItems(FXCollections.observableArrayList("2�ú�", "3��30��", "5�ú�", "6��30�к�", "8�ú�", "9�ú�"));
		cbSYear.setItems(FXCollections.observableArrayList("��ġ��", "��1", "��2", "��3", "��4", "��5", "��6", "��1", "��2", "��3",
				"��1", "��2", "��3", "�Ϲݺ�"));

		
		
		// ���ڸ� �Է� �����ϰ�(�л��ڵ� , �ڵ�����ȣ ,�������,�� , ��, �θ����,������)
		
		DecimalFormat format = new DecimalFormat("################");
		txtSCode.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()
					|| event.getControlNewText().length() == 4) {
				return null;
			} else {
				return event;
			}
		}));
		txtSPhon.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()
					|| event.getControlNewText().length() == 12) {
				return null;
			} else {
				return event;
			}
		}));
		txtSBirthday.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()
					|| event.getControlNewText().length() == 9) {
				return null;
			} else {
				return event;
			}
		}));
		txtDan.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()
					|| event.getControlNewText().length() == 4) {
				return null;
			} else {
				return event;
			}
		}));
		txtClass.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()
					|| event.getControlNewText().length() == 4) {
				return null;
			} else {
				return event;
			}
		}));
		txtPPhone.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()
					|| event.getControlNewText().length() == 12) {
				return null;
			} else {
				return event;
			}
		}));
		txtTuition.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()
					|| event.getControlNewText().length() == 9) {
				return null;
			} else {
				return event;
			}
		}));

		tableStudent.setEditable(false);
		// ���̺� �� ����
		TableColumn colSCode = new TableColumn("�л��ڵ�");
		colSCode.setMaxWidth(60);
		colSCode.setStyle("-fx-allignment: CENTER");
		colSCode.setCellValueFactory(new PropertyValueFactory<>("scode"));

		TableColumn colSname = new TableColumn("�л���");
		colSname.setMaxWidth(60);
		colSname.setStyle("-fx-allignment: CENTER");
		colSname.setCellValueFactory(new PropertyValueFactory<>("sname"));

		TableColumn colTime = new TableColumn("�����ð�");
		colTime.setMaxWidth(60);
		colTime.setStyle("-fx-allignment: CENTER");
		colTime.setCellValueFactory(new PropertyValueFactory<>("time"));

		TableColumn colYear = new TableColumn("�г�");
		colYear.setMaxWidth(60);
		colYear.setStyle("-fx-allignment: CENTER");
		colYear.setCellValueFactory(new PropertyValueFactory<>("year"));

		tableStudent.getColumns().addAll(colSCode, colSname, colTime, colYear);
		// �л� ��ü����
		totalList();
		tableStudent.setItems(data);
		// �⺻�̹���
		localUrl = "/image/default.png";
		locallmage = new Image(localUrl, false);
		imageStudent.setImage(locallmage);

		// ��ü ����Ʈ
		btnTotalList.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				try {
					data.removeAll(data);
					// �л� ��ü ����
					totalList();
				} catch (Exception e) {
					System.out.println(e);
				}
			}

		});
		// �л� ���� ����
		btnEnrollment.setOnAction(event -> {
			try {
				data.removeAll(data);
				StudentVO sVo = null;
				StudentDAO sDao = new StudentDAO();
				File dirMake = new File(dirSave.getAbsolutePath());

				// �̹��� ���� ���� ����
				if (!dirMake.exists()) {
					dirMake.mkdir();
				}

				// �̹��� ���� ����
				String fileName = imageSave(selectedFile);

				// �л� ���� ����
				sVo = new StudentVO();
				sVo.setScode(Integer.parseInt(txtSCode.getText().trim()));
				sVo.setSname(txtSName.getText());
				sVo.setSbirthday(Integer.parseInt(txtSBirthday.getText().trim()));
				sVo.setSphon(txtSPhon.getText());
				sVo.setTuition(Integer.parseInt(txtTuition.getText().trim()));
				sVo.setTime(cbSTime.getSelectionModel().getSelectedItem());
				sVo.setYear(cbSYear.getSelectionModel().getSelectedItem());
				sVo.setDate(Date.valueOf(dpDate.getValue()));
				sVo.setDan(Integer.parseInt(txtDan.getText().trim()));
				sVo.setSclass(Integer.parseInt(txtClass.getText().trim()));
				sVo.setAdd(txtAdd.getText());
				sVo.setPname(txtPName.getText());
				sVo.setPphone(txtPPhone.getText());
				sVo.setFilename(fileName);

				sDao = new StudentDAO();
				sDao.getStudentregiste(sVo);
				if (sDao != null) {
					totalList();
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("�л� ���� �Է�");
					alert.setHeaderText(txtSName.getText() + "�л� ������ �߰��Ǿ����ϴ�.");
					alert.setContentText("���� �Է� ����");


					// �⺻ �̹���
					localUrl = "/image/default.png";
					locallmage = new Image(localUrl, false);
					imageStudent.setImage(locallmage);

					alert.showAndWait();
					txtSCode.clear();
					txtSName.clear();
					txtSPhon.clear();
					txtTuition.clear();
					txtSBirthday.clear();
					txtAdd.clear();
					txtClass.clear();
					txtDan.clear();
					txtPName.clear();
					txtPPhone.clear();
					cbSTime.getSelectionModel().clearSelection();
					cbSYear.getSelectionModel().clearSelection();

					btnModifed.setDisable(false);
					btnTotalList.setDisable(false);
					btnDelete.setDisable(false);
					btnReset.setDisable(false);
				}
			} catch (Exception e) {
				e.getStackTrace();
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�л� ���� �Է�");
				alert.setHeaderText("�л� ������ ��Ȯ�� �Է��ϼ���.");
				alert.setContentText("�������� �����ϼ���.");
				alert.showAndWait();
				totalList();
			}
		});

		btnModifed.setOnAction(event -> handlerBtnModifedAction(event));// ����
		btnExit.setOnAction(event -> handlerBtnExitAction(event));// ����
		btnDelete.setOnAction(event -> handlerBtnDeleteAction(event));// ����
		btnTotalList.setOnAction(event -> handlerBtnTotalList(event));// ��ü
		btnImageFile.setOnAction(event -> handlerBtnImageFile(event));// �̹�������
		tableStudent.setOnMouseClicked(event -> handlerMouse(event));// ���̺� ���� �̺�Ʈ
		btnReset.setOnAction(event -> handlerBtnReset(event));// �ʱ�ȭ
		btnSearch.setOnAction(event -> handlerBtnSearch(event)); // �˻�
	}

	// �˻�
	public void handlerBtnSearch(ActionEvent event) {
		StudentVO sVo = new StudentVO();
		StudentDAO sDao = null;

		Object[][] totalDate = null;
		String SearchName = "";
		boolean searchResult = false;
		try {
			SearchName = txtSearchName.getText().trim();
			sDao = new StudentDAO();
			sVo = sDao.getStudentCheck(SearchName);

			if (SearchName.equals("")) {
				searchResult = true;
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�л� ���� �˻�");
				alert.setHeaderText("�л� �̸��� �Է��Ͻÿ�");
				alert.setContentText("����");
				alert.showAndWait();
			}
			if (!SearchName.equals("") && (sVo != null)) {
				ArrayList<String> title;
				ArrayList<StudentVO> list;

				title = sDao.getColumnName();
				int columnCount = title.size();

				list = sDao.getStudentTotal();
				int rowCount = list.size();

				totalDate = new Object[rowCount][columnCount];

				if (sVo.getSname().equals(SearchName)) {
					txtSearchName.clear();
					data.removeAll(data);
					for (int index = 0; index < rowCount; index++) {
						sVo = list.get(index);
						if (sVo.getSname().equals(SearchName)) {
							data.add(sVo);
							searchResult = true;
							btnTotalList.setDisable(false);
							
						}
					}
				}
			
				if (!searchResult) {
					txtSearchName.clear();
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("�л� ���� �˻�");
					alert.setHeaderText("�л� ����Ʈ�� �����ϴ�.");
					alert.setContentText("�ٽ� �˻��ϼ���.");
					alert.showAndWait();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// �ʱ�ȭ
	public void handlerBtnReset(ActionEvent event) {
		txtSCode.clear();
		txtAdd.clear();
		txtClass.clear();
		txtDan.clear();
		txtPName.clear();
		txtTuition.clear();
		txtPPhone.clear();
		txtSBirthday.clear();
		txtSearchName.clear();
		txtSName.clear();
		txtSPhon.clear();
		cbSTime.getSelectionModel().clearSelection();
		cbSYear.getSelectionModel().clearSelection();
		localUrl = "/image/default.png";
		locallmage = new Image(localUrl, false);
		imageStudent.setImage(locallmage);
		btnModifed.setDisable(false);
		btnTotalList.setDisable(false);
		btnReset.setDisable(true);
		btnDelete.setDisable(true);
		btnEnrollment.setDisable(false);
		

	}

	// ��ü
	public void handlerBtnTotalList(ActionEvent event) {
		try {
			data.removeAll(data);
			totalList();

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	// ���̺� �̺�Ʈ
	public void handlerMouse(MouseEvent event) {
		try {
			if (event.getClickCount() != 2) {
				cbSYear.setEditable(true);
				cbSTime.setEditable(true);
				btnImageFile.setDisable(false);

				selectStudent = tableStudent.getSelectionModel().getSelectedItems();

				LocalDate date = selectStudent.get(0).getDate().toLocalDate();

				txtSName.setText(selectStudent.get(0).getSname());
				cbSYear.setValue(selectStudent.get(0).getYear());
				cbSTime.setValue(selectStudent.get(0).getTime());
				txtSCode.setText(selectStudent.get(0).getScode() + "");
				txtSBirthday.setText(selectStudent.get(0).getSbirthday() + "");
				txtSPhon.setText(selectStudent.get(0).getSphon());
				txtTuition.setText(selectStudent.get(0).getTuition()+"");
				txtDan.setText(selectStudent.get(0).getDan() + "");
				txtClass.setText(selectStudent.get(0).getSclass() + "");
				txtAdd.setText(selectStudent.get(0).getAdd() + "");
				txtPName.setText(selectStudent.get(0).getPname() + "");
				txtPPhone.setText(selectStudent.get(0).getPphone());
				dpDate.setValue(date);
				selectFileName = selectStudent.get(0).getFilename();

				txtSName.setEditable(true);
				txtSBirthday.setEditable(true);
				txtSPhon.setEditable(true);
				txtTuition.setEditable(true);
				txtDan.setEditable(true);
				txtClass.setEditable(true);
				txtAdd.setEditable(true);
				txtPName.setEditable(true);
				txtPPhone.setEditable(true);
				txtSCode.setEditable(true);
				dpDate.setEditable(false);

				localUrl = "file:/C:/images/" + selectFileName;
				locallmage = new Image(localUrl, false);
				imageStudent.setImage(locallmage);
				imageStudent.setFitHeight(200);
				imageStudent.setFitWidth(200);

				btnDelete.setDisable(false);
				btnModifed.setDisable(false);
				btnEnrollment.setDisable(true);
				btnReset.setDisable(false);
			}
		} catch (Exception e) {
			
		}

	}

	// ����â
	public void setPrimaryStage(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}

	// �̹��� ����
	public String imageSave(File file) {
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;

		int data = -1;
		String fileName = null;
		try {
			// �̹��� ���ϸ� ����
			fileName = "student" + System.currentTimeMillis() + "_" + file.getName();
			bis = new BufferedInputStream(new FileInputStream(file));
			bos = new BufferedOutputStream(new FileOutputStream(dirSave.getAbsolutePath() + "\\" + fileName));

			// ������ �̹��� ���� inputStream�� �������� �̸����� ��� -1
			while ((data = bis.read()) != -1) {
				bos.write(data);
				bos.flush();

			}
		} catch (Exception e) {
			System.out.println("3242344343");
			System.out.println(e);
			e.printStackTrace();

		} finally {
			try {
				if (bos != null) {
					bos.close();
				}
				if (bis != null) {
					bis.close();
				}
			} catch (IOException e) {
				e.getMessage();
			}
		}
		return fileName;
	}

	// �̹��� ���� ����
	public boolean imageDelete(String fileName) {
		boolean result = false;
		try {
			File fileDelete = new File(dirSave.getAbsolutePath() + "\\" + fileName); // ���� �̹��� ����

			if (fileDelete.exists() && fileDelete.isFile()) {
				result = fileDelete.delete();
				// �⺻ �̹���
				localUrl = "/image/default.png";
				locallmage = new Image(localUrl, false);
				imageStudent.setImage(locallmage);
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
			result = false;
		}
		return result;
	}

	// �̹��� ���� ���� â
	public void handlerBtnImageFile(ActionEvent event) {
		FileChooser fileChooser = new FileChooser();
		fileChooser.getExtensionFilters().addAll(new ExtensionFilter("Image File", "*.png", "*.jpg", "*.gif"));
		try {
			selectedFile = fileChooser.showOpenDialog(primaryStage);
			if (selectedFile != null) {
				// �̹��� ���
				localUrl = selectedFile.toURI().toURL().toString();
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		locallmage = new Image(localUrl, false);
		imageStudent.setImage(locallmage);
		imageStudent.setFitHeight(200);
		imageStudent.setFitWidth(200);
		if (selectedFile != null) {
			selectFileName = selectedFile.getName();
		}
	}

	// ��ü ����Ʈ
	public void totalList() {
		Object[][] totalData;

		StudentDAO sDao = new StudentDAO();
		StudentVO sVo = new StudentVO();
		ArrayList<String> title;
		ArrayList<StudentVO> list;

		title = sDao.getColumnName();
		int columnCount = title.size();

		list = sDao.getStudentTotal();
		int rowCount = list.size();
		totalData = new Object[rowCount][columnCount];

		for (int index = 0; index < rowCount; index++) {
			sVo = list.get(index);
			data.add(sVo);
		}
	}

	// ������ư
	public void handlerBtnDeleteAction(ActionEvent event) {
		StudentDAO sDao = null;
		sDao = new StudentDAO();

		try {
			sDao.getStudentDelete(selectStudent.get(0).getScode());
			System.out.println(scode);
			data.removeAll(data);
			// �л� ��ü ����
			totalList();
			// �̹��� ����
			imageDelete(selectFileName);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// �����ư
	public void handlerBtnExitAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/MainView.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scane = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("ü���� ���� ���α׷�");
			mainMtage.setScene(scane);
			Stage oldStage = (Stage) btnExit.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (IOException e) {
			System.out.println("����  " + e);
		}
	}

	// ������ư
	public void handlerBtnModifedAction(ActionEvent event) {
		try {
			StudentVO sVo = new StudentVO();
			StudentDAO sDao = new StudentDAO();
			File dirMake = new File(dirSave.getAbsolutePath());

			// �̹��� ���� ���� ����
			if (!dirMake.exists()) {
				dirMake.mkdir();
			}

			// �̹��� ���� ����
			String fileName = imageSave(selectedFile);

			try {
				data.remove(selectedIndex);
				sVo.setScode(Integer.parseInt(txtSCode.getText().trim()));
				sVo.setSname(txtSName.getText());
				sVo.setSbirthday(Integer.parseInt(txtSBirthday.getText().trim()));
				sVo.setSphon(txtSPhon.getText());
				sVo.setTuition(Integer.parseInt(txtTuition.getText().trim()));
				sVo.setTime(cbSTime.getSelectionModel().getSelectedItem());
				sVo.setYear(cbSYear.getSelectionModel().getSelectedItem());
				sVo.setDan(Integer.parseInt(txtDan.getText().trim()));
				sVo.setSclass(Integer.parseInt(txtClass.getText().trim()));
				sVo.setAdd(txtAdd.getText());
				sVo.setPname(txtPName.getText());
				sVo.setPphone(txtPPhone.getText());
				sVo.setFilename(fileName);

				sDao.getStudentUpdate(sVo, sVo.getScode());

				data.removeAll(data);
				totalList();

				if (sDao != null) {

					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("�л� ���� �Է�");
					alert.setHeaderText(txtSName.getText() + "�л� ������ �߰��Ǿ����ϴ�.");
					alert.setContentText("���� �Է� ����");

					btnImageFile.setDisable(true);

					// �⺻ �̹���
					localUrl = "/image/default.png";
					locallmage = new Image(localUrl, false);
					imageStudent.setImage(locallmage);

					alert.showAndWait();
				}
			} catch (Exception e) {
				System.out.println(e);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}