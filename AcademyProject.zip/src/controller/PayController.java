package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParsePosition;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.PayVO;

public class PayController implements Initializable {
	@FXML
	private TableView<PayVO> TablePay = new TableView<>();
	@FXML
	private TextField txtSName;
	@FXML
	private TextField txtSCode;
	@FXML
	private TextField txtPBriefs;
	@FXML
	private TextField txtPWay;
	@FXML
	private TextField txtPPrice;
	@FXML
	private DatePicker dpPDay; //���Գ�¥
	@FXML
	private DatePicker dpPClaim; //û����¥
	@FXML
	private TextField txtLookup;
	@FXML
	private Button btnLookup;
	@FXML
	private Button btnEnrollment;
	@FXML
	private Button btnAll;
	@FXML
	private Button btnExit;
	@FXML
	private Button btnDelete;
	@FXML
	private Button btnReset;

	ObservableList<PayVO> data = FXCollections.observableArrayList();
	ObservableList<PayVO> selectPay = null;// ���̺����� ������ ���� ����
	int selectedIndex;
	int scode; // ������ ���̺����� ������ �л��� ��ȣ ����

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		btnDelete.setDisable(true);
		btnEnrollment.setDisable(false);
		// ���ڸ� �Է�(�л��ڵ� , �Աݾ�)
		DecimalFormat format = new DecimalFormat("###############");
		txtSCode.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()
					|| event.getControlNewText().length() == 4) {
				return null;
			} else {
				return event;
			}
		}));
		txtPPrice.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()
					|| event.getControlNewText().length() == 9) {
				return null;
			} else {
				return event;
			}
		}));

		TablePay.setEditable(false);
		// ���̺� �� ����
		TableColumn colSCode = new TableColumn("�л��ڵ�");
		colSCode.setMaxWidth(60);
		colSCode.setStyle("-fx-allignment: CENTER");
		colSCode.setCellValueFactory(new PropertyValueFactory<>("SCode"));

		TableColumn colSName = new TableColumn("�л��̸�");
		colSName.setMaxWidth(60);
		colSName.setStyle("-fx-allignment: CENTER");
		colSName.setCellValueFactory(new PropertyValueFactory<>("SName"));

		TableColumn colPDay = new TableColumn("��������");
		colPDay.setMaxWidth(100);
		colPDay.setStyle("-fx-allignment: CENTER");
		colPDay.setCellValueFactory(new PropertyValueFactory<>("PDay"));

		TableColumn colPClaim = new TableColumn("û������");
		colPClaim.setMaxWidth(100);
		colPClaim.setStyle("-fx-allignment: CENTER");
		colPClaim.setCellValueFactory(new PropertyValueFactory<>("PClaim"));

		TableColumn colPPrice = new TableColumn("�Աݾ�");
		colPPrice.setMaxWidth(100);
		colPPrice.setStyle("-fx-allignment: CENTER");
		colPPrice.setCellValueFactory(new PropertyValueFactory<>("PDeposit"));

		TableColumn colPBriefs = new TableColumn("�Ա�����");
		colPBriefs.setMaxWidth(60);
		colPBriefs.setStyle("-fx-allignment: CENTER");
		colPBriefs.setCellValueFactory(new PropertyValueFactory<>("PBriefs"));

		TableColumn colPWay = new TableColumn("�Աݹ��");
		colPWay.setMaxWidth(60);
		colPWay.setStyle("-fx-allignment: CENTER");
		colPWay.setCellValueFactory(new PropertyValueFactory<>("PWay"));

		TablePay.getColumns().addAll(colSCode, colSName, colPDay, colPClaim, colPPrice, colPBriefs, colPWay);
		// ���� ��ü����
		totalList();
		TablePay.setItems(data);

		// ���� ��ü ����Ʈ
		btnAll.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				try {
					data.removeAll(data);
					totalList();
				} catch (Exception e) {
					System.out.println(e);
				}
			}
		});
		// ���� ���� ����
		btnEnrollment.setOnAction(event -> {
			try {
				
				PayVO pVo = null;
				PayDAO pDao = new PayDAO();

				if(dpPDay.getValue().isBefore(dpPClaim.getValue())) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("��¥ �Է� ����");
					alert.setHeaderText("���Գ�¥�� û����¥���� ���� �̸� �ȵ˴ϴ�.");
					alert.setContentText("�������� �����ϼ���.");
					alert.showAndWait();
					data.removeAll(data);
					totalList();
					return; //��ȿ
				}

				// ���� ���� ����
				pVo = new PayVO();
				pVo.setPDay(Date.valueOf(dpPDay.getValue()));
				pVo.setSName(txtSName.getText());
				pVo.setSCode(Integer.parseInt(txtSCode.getText().trim()));
				pVo.setPBriefs(txtPBriefs.getText());
				pVo.setPWay(txtPWay.getText());
				pVo.setPClaim(Date.valueOf(dpPClaim.getValue()));
				pVo.setPDeposit(Integer.parseInt(txtPPrice.getText().trim()));
				pDao = new PayDAO();
				pDao.getPayregiste(pVo);
				
				if (pDao != null) {
					data.removeAll(data);
					totalList();
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("�л� ���� �Է�");
					alert.setHeaderText(txtSName.getText() + "�л� ���� ������ �߰��Ǿ����ϴ�.");
					alert.setContentText("���� �Է� ����");
					alert.showAndWait();

					txtPBriefs.clear();
					txtPPrice.clear();
					txtPWay.clear();
					txtSCode.clear();
					txtSName.clear();
				}
			} catch(SQLException e) {
				e.getStackTrace();
				
			}
			catch (Exception e) {
				e.getStackTrace();
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�л� ���� �Է�");
				alert.setHeaderText("�л� ������ ��Ȯ�� �Է��ϼ���.");
				alert.setContentText("�������� �����ϼ���.");
				alert.showAndWait();
				
			}
		});

		btnAll.setOnAction(event -> handlerBtnAll(event));// ��ü
		btnDelete.setOnAction(event -> handlerBtnDelete(event));// ����
		btnExit.setOnAction(event -> handlerBtnExit(event));// ����
		btnLookup.setOnAction(event -> handlerBtnLookup(event));// �˻�
		btnReset.setOnAction(event -> handlerBtnReset(event));//�ʱ�ȭ
		TablePay.setOnMouseClicked(event -> handlerMouse(event));//���̺� ���� �̺�Ʈ
		
	}
	//�ʱ�ȭ
	public void handlerBtnReset(ActionEvent event) {
		txtLookup.clear();
		txtPBriefs.clear();
		txtPPrice.clear();
		txtPWay.clear();
		txtSCode.clear();
		txtSName.clear();
		btnEnrollment.setDisable(false);
		btnDelete.setDisable(true);
	}
	//���̺� ���� 
	public void handlerMouse(MouseEvent event) {
		try {
			if (event.getClickCount() != 2) {
				

				selectPay = TablePay.getSelectionModel().getSelectedItems();

				LocalDate day = selectPay.get(0).getPDay().toLocalDate();
				LocalDate claim = selectPay.get(0).getPClaim().toLocalDate();
				
				txtSName.setText(selectPay.get(0).getSName());
				txtSCode.setText(selectPay.get(0).getSCode() + "");
				txtPWay.setText(selectPay.get(0).getPWay());
				txtPPrice.setText(selectPay.get(0).getPDeposit()+"");
				txtPBriefs.setText(selectPay.get(0).getPBriefs());
				dpPClaim.setValue(claim);
				dpPDay.setValue(day);
				
				

				btnDelete.setDisable(false);
				btnEnrollment.setDisable(true);
				btnReset.setDisable(false);
			}
		} catch (Exception e) {
		}

	}

	// ��ü ����Ʈ
	public void totalList() {
		Object[][] totalData;

		PayDAO pDao = new PayDAO();
		PayVO pVo = new PayVO();
		ArrayList<String> title;
		ArrayList<PayVO> list;

		title = pDao.getColumnName();
		int columnCount = title.size();

		list = pDao.getPayTotal();
		int rowCount = list.size();
		totalData = new Object[rowCount][columnCount];

		for (int index = 0; index < rowCount; index++) {
			pVo = list.get(index);
			data.add(pVo);
		}
	}

	// ��ü
	public void handlerBtnAll(ActionEvent event) {
		try {
			data.removeAll(data);
			totalList();
		} catch (Exception e) {
			e.getStackTrace();
		}
	}

	// ����
	public void handlerBtnDelete(ActionEvent event) {
		PayDAO sDao = null;
		sDao = new PayDAO();

		try {
			sDao.getPayDelete(selectPay.get(0).getSCode());
			data.removeAll(data);
			// �л� ��ü ����
			totalList();
			

		} catch (Exception e) {
			e.getStackTrace();
		}
	}

	// ����
	public void handlerBtnExit(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/MainView.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scane = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("ü���� ���� ���α׷�");
			mainMtage.setScene(scane);
			Stage oldStage = (Stage) btnExit.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (IOException e) {
			System.out.println("����  " + e);
		}
	}

	// �˻�
	public void handlerBtnLookup(ActionEvent event) {
		PayVO pVo = new PayVO();
		PayDAO pDao = null;

		Object[][] totalDate = null;
		String SearchName = "";
		boolean searchResult = false;
		try {
			SearchName = txtLookup.getText().trim();
			pDao = new PayDAO();
			pVo = pDao.getPayCheck(SearchName);

			if (SearchName.equals("")) {
				searchResult = true;
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�л� ���� �˻�");
				alert.setHeaderText("�л� �̸��� �Է��Ͻÿ�");
				alert.setContentText("����");
				alert.showAndWait();
			}
			if (!SearchName.equals("") && (pVo != null)) {
				ArrayList<String> title;
				ArrayList<PayVO> list;

				title = pDao.getColumnName();
				int columnCount = title.size();

				list = pDao.getPayTotal();
				int rowCount = list.size();

				totalDate = new Object[rowCount][columnCount];

				if (pVo.getSName().equals(SearchName)) {
					txtLookup.clear();
					data.removeAll(data);
					for (int index = 0; index < rowCount; index++) {
						pVo = list.get(index);
						if (pVo.getSName().equals(SearchName)) {
							data.add(pVo);
							searchResult = true;
							btnAll.setDisable(false);

						}
					}
				}

				if (!searchResult) {
					txtLookup.clear();
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("�л� ���� �˻�");
					alert.setHeaderText("�л� ����Ʈ�� �����ϴ�.");
					alert.setContentText("�ٽ� �˻��ϼ���.");
					alert.showAndWait();
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
		}
	}
}
