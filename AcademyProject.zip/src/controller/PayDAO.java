package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.PayVO;

public class PayDAO {
	// ��� ���
	public PayVO getPayregiste(PayVO pvo) throws Exception {

		StringBuffer sql = new StringBuffer();
		sql.append("insert into pay ");
		sql.append("(p_code ,s_name,s_code,p_day,p_briefs,p_way,p_claim,p_price) ");
		sql.append("values(seq_pay.nextval,?,?,?,?,?,?,?)");

		Connection con = null;
		PreparedStatement pstmt = null;
		PayVO pVo = pvo;
		System.out.println("44444");
		try {
			// ������ ���̽� ����
			con = DBUtil.getConnection();

			// �Է¹��� ���� ó��
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, pVo.getSName());
			pstmt.setInt(2, pVo.getSCode());
			pstmt.setDate(3, pVo.getPDay());
			pstmt.setString(4, pVo.getPBriefs());
			pstmt.setString(5,pVo.getPWay());
			pstmt.setDate(6, pVo.getPClaim());
			pstmt.setInt(7, pVo.getPDeposit());
			
			int i = pstmt.executeUpdate();
			System.out.println(i);
		} catch(SQLException e) {
			e.getStackTrace();
		} catch (Exception e) {
			e.getStackTrace();
		}finally {
			try {
				if(pstmt != null) {
					pstmt.close();
				}if(con != null){
					con.close();
				}
			}catch(SQLException e) {
				e.getStackTrace();
			}
		}

		return pvo;
	}

	// ���� ��ȸ
	public PayVO getPayCheck(String sname) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("select * from Pay where s_name like ");
		sql.append("? order by s_name desc");

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		PayVO pVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, "%" + sname + "%");

			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				pVo = new PayVO();
				pVo.setSName(rs.getString("s_name"));
				pVo.setSCode(rs.getInt("s_code"));
				pVo.setPDay(rs.getDate("p_day"));
				pVo.setPBriefs(rs.getString("p_briefs"));
				pVo.setPWay(rs.getString("p_way"));
				pVo.setPClaim(rs.getDate("p_claim"));
				pVo.setPDeposit(rs.getInt("p_price"));
			}
		} catch (SQLException e) {
			e.getStackTrace();
		} catch (Exception e) {
			e.getStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				e.getStackTrace();
			}
		}
		return pVo;
	}

	// �����ͺ��̽� ���� ���̺��� �÷���
	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();
		StringBuffer sql = new StringBuffer();
		sql.append("select * from pay");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException e) {
			e.getStackTrace();
		} catch (Exception e) {
			e.getStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				e.getStackTrace();
			}
		}
		return columnName;
	}

	// ���� ��ü ����Ʈ
	public ArrayList<PayVO> getPayTotal() {
		ArrayList<PayVO> list = new ArrayList<PayVO>();
		StringBuffer sql = new StringBuffer();
		sql.append("select * from Pay ");

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		PayVO pVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				pVo = new PayVO();
				pVo.setSName(rs.getString("s_name"));
				pVo.setSCode(rs.getInt("s_code"));
				pVo.setPDay(rs.getDate("p_day"));
				pVo.setPBriefs(rs.getString("p_briefs"));
				pVo.setPWay(rs.getString("p_way"));
				pVo.setPClaim(rs.getDate("p_claim"));
				pVo.setPDeposit(rs.getInt("p_price"));

				list.add(pVo);
			}
		} catch (SQLException e) {
			e.getStackTrace();
		} catch (Exception e) {
			e.getStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				e.getStackTrace();
			}
		}
		return list;
	}

	// �������� ����
	public void getPayDelete(int Scode) throws Exception {
		// ������ ó��
		StringBuffer sql = new StringBuffer();
		sql.append("delete from pay where s_code =?");
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			// �����ͺ��̽� ����
			con = DBUtil.getConnection();

			// ó����� ����
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, Scode);

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���� ���� ����");
				alert.setHeaderText("���� ���� ���� �Ϸ�");
				alert.setContentText("���� ����");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���� ���� ����");
				alert.setHeaderText("���� ���� ���� ����");
				alert.setContentText("���� ����");
				alert.showAndWait();
			}
		} catch (SQLException e) {
			e.getStackTrace();
		} catch (Exception e) {
			e.getStackTrace();
		} finally {
			try {
				// ������Ʈ ����
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				e.getStackTrace();
			}
		}
	}
}
