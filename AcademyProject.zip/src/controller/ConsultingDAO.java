package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.ConsultingVO;
import model.StudentVO;

public class ConsultingDAO {
	//�ű� ���
	public ConsultingVO getConsultingregiste(ConsultingVO cvo) throws Exception{
		//������ ó��
		StringBuffer sql = new StringBuffer();
		sql.append("insert into Consulting ");
		sql.append("(c_no,c_day,c_name,s_name,s_code,c_contents)");
		sql.append("values(seq_consulting.nextval,?,?,?,?,?)");
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ConsultingVO cVo = cvo;
		
		try {
			con = DBUtil.getConnection();
			
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setDate(1, cVo.getCDay());
			pstmt.setString(2, cVo.getCName());
			pstmt.setString(3, cVo.getSName());
			pstmt.setInt(4, cVo.getSCode());
			pstmt.setString(5, cVo.getContents());
			
			int i = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.getStackTrace();
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			try {
				if(pstmt != null) {
					pstmt.close();
				}if(con != null) {
					con.close();
				}
			}catch(SQLException e) {
				e.getStackTrace();
			}
		}
		return cvo;
	}
	
	//��ȸ
	public ConsultingVO getConsultingcheck(String sname) throws Exception{
		StringBuffer sql = new StringBuffer();
		sql.append("select * from Consulting where s_name like ");
		sql.append("? order by s_name desc");
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs =null;
		ConsultingVO cVo = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, "%"+sname+"%");
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				cVo = new ConsultingVO();
				cVo.setCDay( rs.getDate("c_day"));
				cVo.setCName(rs.getString("c_name"));
				cVo.setSName(rs.getString("s_name"));
				cVo.setSCode(rs.getInt("s_code"));
				cVo.setContents(rs.getString("c_contents"));
			}
		}catch(SQLException e) {
			e.getStackTrace();
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			try {
				if(rs != null) {
					rs.close();
				}if(pstmt != null) {
					pstmt.close();
				}if(con != null) {
					con.close();
				}
			}catch(SQLException e) {
				e.getStackTrace();
			}
		}
		
		return cVo;
	}
	
	//����
	public void getConsultingDelete(int scode) throws Exception{
		StringBuffer sql = new StringBuffer();
		sql.append("delete from consulting where s_code =?");
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = DBUtil.getConnection();
			
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, scode);
			
			int i = pstmt.executeUpdate();
			
			if(i ==1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��� ����");
				alert.setHeaderText("��� ���� ���� �Ϸ�");
				alert.setContentText("���� ����");
				alert.showAndWait();
			}else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��� ����");
				alert.setHeaderText("��� ���� ���� ����");
				alert.setContentText("���� ����");
				alert.showAndWait();
			}
			
		}catch(SQLException e) {
			e.getStackTrace();
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			try {
			if(pstmt != null) {
				pstmt.close();
			}if(con != null) {
				con.close();
			}
			}catch(SQLException e) {
				e.getStackTrace();
			}
		}
	}
	
	//�л� ��ü ����Ʈ
	public ArrayList<ConsultingVO> getConsultingTotal(){
		ArrayList<ConsultingVO> list = new ArrayList<ConsultingVO>();
		StringBuffer sql = new StringBuffer();
		sql.append("select * from consulting");
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ConsultingVO cVo = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs=pstmt.executeQuery();
			while (rs.next()) {
				cVo = new ConsultingVO();
				cVo.setCDay( rs.getDate("c_day"));
				cVo.setCName(rs.getString("c_name"));
				cVo.setSName(rs.getString("s_name"));
				cVo.setSCode(rs.getInt("s_code"));
				cVo.setContents(rs.getString("c_contents"));
				
				list.add(cVo);
			}
			
		}catch(SQLException e){
			e.getStackTrace();
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			try {
				if(rs != null) {
					rs.close();
				}if(pstmt != null) {
					pstmt.close();
				}if(con != null) {
					con.close();
				}
			}catch(SQLException e) {
				e.getStackTrace();
			}
		}
		return list;
	}

	// �����ͺ��̽� �л� ���̺��� �÷���
		public ArrayList<String> getColumnName() {
			ArrayList<String> columnName = new ArrayList<String>();
			StringBuffer sql = new StringBuffer();
			sql.append("select * from consulting");
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			ResultSetMetaData rsmd = null;
			try {
				con = DBUtil.getConnection();
				pstmt = con.prepareStatement(sql.toString());
				rs = pstmt.executeQuery();
				rsmd = rs.getMetaData();
				int cols = rsmd.getColumnCount();
				for (int i = 1; i <= cols; i++) {
					columnName.add(rsmd.getColumnName(i));
				}
			} catch (SQLException e) {
				System.out.println(e);
			} catch (Exception e) {
				System.out.println(e);
			} finally {
				try {
					if (rs != null) {
						rs.close();
					}
					if (pstmt != null) {
						pstmt.close();
					}
					if (con != null) {
						con.close();
					}
				} catch (SQLException e) {
					System.out.println(e);
				}
			}
			return columnName;
		}
		// ���� �л� ���� ����
		public ConsultingVO getConsultingUpdate(ConsultingVO cvo, int scode) throws Exception {
			// ������ ó��
			StringBuffer sql = new StringBuffer();
			sql.append("update consulting set ");
			sql.append(
					"c_day=?,c_name=?,s_name=?,c_contents=? ");
			sql.append("where s_code = ?");
			Connection con = null;
			PreparedStatement pstmt = null;
			ConsultingVO retval = null;

			try {
				// �����ͺ��̽� ����
				con = DBUtil.getConnection();
				// �л������� ����
				pstmt = con.prepareStatement(sql.toString());
				pstmt.setDate(1, cvo.getCDay());
				pstmt.setString(2, cvo.getCName());
				pstmt.setString(3, cvo.getSName());
				pstmt.setString(4, cvo.getContents());
				pstmt.setInt(5, cvo.getSCode());
				// ó����� ����
				int i = pstmt.executeUpdate();

				if (i == 1) {
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("��� ����");
					alert.setHeaderText("��� ���� �Ϸ�");
					alert.setContentText("��� ���� ����");
					alert.showAndWait();
					retval = new ConsultingVO();
				} else {
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("��� ����");
					alert.setHeaderText("��� ���� ����");
					alert.setContentText("��� ���� ����");
					alert.showAndWait();
				}
			} catch (SQLException e) {
				System.out.println(e);
				e.getStackTrace();
			} catch (Exception e) {
				System.out.println(e);
				e.getStackTrace();
			} finally {
				try {
					// ������Ʈ ����
					if (pstmt != null) {
						pstmt.close();
					}
					if (con != null) {
						con.close();
					}
				} catch (SQLException e) {
					System.out.println(e);
					e.getStackTrace();
				}
			}
			return retval;
		}
}
