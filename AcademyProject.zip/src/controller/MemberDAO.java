package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.MemberVO;

public class MemberDAO {
	//���
	public MemberVO getMemberRegiste(MemberVO mvo) throws Exception{
		String dml = "insert into member (m_passwold,m_name,m_phon,m_academycode) "
				+ "values (?,?,?,?)";
		Connection con = null;
		PreparedStatement pstmt = null;
		MemberVO retval = null;
		
		try {
			//DBUtil Ŭ������ getConnection() �޼���� ������ ���̽� ����
			con = DBUtil.getConnection();
			
			//�Է¹��� ������ ������ ó��
			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, mvo.getMPassword());
			pstmt.setString(2, mvo.getManagerName());
			pstmt.setInt(3, mvo.getManagerPhon());
			pstmt.setInt(4, mvo.getAcademyCode());
			
			//sql���� ������ ó�� ���
			int i = pstmt.executeUpdate();
			
			retval = new MemberVO();
		}catch(SQLException e) {
			System.out.println("���� : "+e);
		}catch(Exception e) {
			System.out.println("���� : "+e);
		}finally {
			try {
				if(pstmt != null) {
					pstmt.close();
				}if(con != null) {
					con.close();
				}
			}catch(SQLException e) {
				
			}
		}
		return retval;
	}
	//�α���
	public MemberVO getMemberCheck(  String MPassword , int AcademyCode) throws Exception{
		String dml = "select * from Member where m_passwold =? and m_academycode = ? ";
		Connection con = null;
		PreparedStatement pstmt = null;  //����ǥ ����
		ResultSet rs = null; //�����ͺ��̽� ���� ������ �ʿ��� ���� 
		MemberVO mVo = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, MPassword);
			pstmt.setInt(2, AcademyCode);
			
			
			rs = pstmt.executeQuery(); //dml �� ���� rs�� ��ƶ� 
			if(rs.next()) {
				mVo = new MemberVO();
				mVo.setMPassword(rs.getString("m_passwold"));
				mVo.setAcademyCode(rs.getInt("m_academycode"));
				mVo.setManagerName(rs.getString("m_name"));
				System.out.println(rs.getString("m_passwold"));
				System.out.println(rs.getInt("m_academycode"));
				System.out.println(rs.getString("m_name"));
			}else {
				mVo = new MemberVO();
				mVo.setMPassword(null);
				mVo.setAcademyCode(0);
			}
			
		}catch(SQLException e) {
			e.getStackTrace();
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			try {
				if(rs != null) {
					rs.close();
				}if(pstmt != null){
					pstmt.close();
				}if(con != null) {
					con.close();
				}
			}catch(SQLException e) {
				System.out.println(e);
			}
		}
		
		return mVo;
	}
}
