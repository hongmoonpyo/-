package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.StudentVO;

public class StudentDAO {
	// �ű� �л� ���
	public StudentVO getStudentregiste(StudentVO svo) throws Exception {
		// ������ ó��
		StringBuffer sql = new StringBuffer();
		sql.append("insert into student ");
		sql.append(
				"(s_code,s_name,s_birthday,s_phon,s_Tuition,s_time,s_year,s_date,s_dan,s_class,s_add,s_p_name,s_p_phon,filename) ");
		sql.append("values(?,?,?,?,?,?,?,sysdate,?,?,?,?,?,?)");

		Connection con = null;
		PreparedStatement pstmt = null;
		StudentVO sVo = svo;

		try {
			// �����ͺ��̽� ����
			con = DBUtil.getConnection();

			// �Է¹��� ���� ó��
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, sVo.getScode());
			pstmt.setString(2, sVo.getSname());
			pstmt.setInt(3, sVo.getSbirthday());
			pstmt.setString(4, sVo.getSphon());
			pstmt.setInt(5, sVo.getTuition());
			pstmt.setString(6, sVo.getTime());
			pstmt.setString(7, sVo.getYear());
			pstmt.setInt(8, sVo.getDan());
			pstmt.setInt(9, sVo.getSclass());
			pstmt.setString(10, sVo.getAdd());
			pstmt.setString(11, sVo.getPname());
			pstmt.setString(12, sVo.getPphone());
			pstmt.setString(13, sVo.getFilename());
			// ó����� ����
			int i = pstmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println(e);
			System.out.println("111111");
			e.getStackTrace();
		} catch (Exception e) {
			System.out.println("11121");
			e.getStackTrace();
		} finally {
			try {// ������Ʈ ����
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				System.out.println("1222221");
				System.out.println(e);
				e.getStackTrace();
			}
		}
		return sVo;
	}

	// �л� ��ȸ
	public StudentVO getStudentCheck(String sname) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("select * from student where s_name like ");
		sql.append("? order by s_name desc");

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StudentVO sVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, "%" + sname + "%");

			rs = pstmt.executeQuery();

			if (rs.next()) {
				sVo = new StudentVO();
				sVo.setScode(rs.getInt("s_code"));
				sVo.setSname(rs.getString("s_name"));
				sVo.setSbirthday(rs.getInt("s_birthday"));
				sVo.setSphon(rs.getString("s_phon"));
				sVo.setTuition(rs.getInt("s_tuition"));
				sVo.setTime(rs.getString("s_time"));
				sVo.setYear(rs.getString("s_year"));
				sVo.setDate(rs.getDate("s_date"));
				sVo.setDan(rs.getInt("s_dan"));
				sVo.setSclass(rs.getInt("s_class"));
				sVo.setAdd(rs.getString("s_add"));
				sVo.setPname(rs.getString("s_p_name"));
				sVo.setPphone(rs.getString("s_p_phon"));
				sVo.setFilename(rs.getString("filename"));

			}
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
		return sVo;
	}

	// ���� �л� ���� ����
	public StudentVO getStudentUpdate(StudentVO svo, int Scode) throws Exception {
		// ������ ó��
		StringBuffer sql = new StringBuffer();
		sql.append("update Student set ");
		sql.append(
				"s_name=?,s_birthday=?,s_phon=?,s_tuition=?,s_time=?,s_year=?,s_dan=?,s_class=?,s_add=?,s_p_name=?,s_p_phon=?,filename=?");
		sql.append("where s_code = ?");
		Connection con = null;
		PreparedStatement pstmt = null;
		StudentVO retval = null;

		try {
			// �����ͺ��̽� ����
			con = DBUtil.getConnection();
			// �л������� ����
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, svo.getSname());
			pstmt.setInt(2, svo.getSbirthday());
			pstmt.setString(3, svo.getSphon());
			pstmt.setInt(4, svo.getTuition());
			pstmt.setString(5, svo.getTime());
			pstmt.setString(6, svo.getYear());
			pstmt.setInt(7, svo.getDan());
			pstmt.setInt(8, svo.getSclass());
			pstmt.setString(9, svo.getAdd());
			pstmt.setString(10, svo.getPname());
			pstmt.setString(11, svo.getPphone());
			pstmt.setString(12, svo.getFilename());
			pstmt.setInt(13, svo.getScode());
			// ó����� ����
			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�л� ����");
				alert.setHeaderText("�л� ���� �Ϸ�");
				alert.setContentText("�л� ���� ����");
				alert.showAndWait();
				retval = new StudentVO();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�л� ����");
				alert.setHeaderText("�л� ���� ����");
				alert.setContentText("�л� ���� ����");
				alert.showAndWait();
			}
		} catch (SQLException e) {
			System.out.println("12455333");
			System.out.println(e);
			e.getStackTrace();
		} catch (Exception e) {
			System.out.println("23253546");
			System.out.println(e);
			e.getStackTrace();
		} finally {
			try {
				// ������Ʈ ����
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				System.out.println("43434343");
				System.out.println(e);
				e.getStackTrace();
			}
		}
		return retval;
	}

	// �������� ����
	public void getStudentDelete(int Scode) throws Exception {
		// ������ ó��
		StringBuffer sql = new StringBuffer();
		sql.append("delete from student where s_code =?");
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			// �����ͺ��̽� ����
			con = DBUtil.getConnection();

			// ó����� ����
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, Scode);
			System.out.println(Scode);

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�л� ����");
				alert.setHeaderText("�л� ���� ���� �Ϸ�");
				alert.setContentText("���� ����");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�л� ����");
				alert.setHeaderText("�л� ���� ����");
				alert.setContentText("���� ����");
				alert.showAndWait();
			}
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				// ������Ʈ ����
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
	}

	// �л� ��ü ����Ʈ
	public ArrayList<StudentVO> getStudentTotal() {
		ArrayList<StudentVO> list = new ArrayList<StudentVO>();
		StringBuffer sql = new StringBuffer();
		sql.append("select * ");
		sql.append("from student ");

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StudentVO sVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				sVo = new StudentVO();
				sVo.setScode(rs.getInt("s_code"));
				sVo.setSname(rs.getString("s_name"));
				sVo.setSbirthday(rs.getInt("s_birthday"));
				sVo.setSphon(rs.getString("s_phon"));
				sVo.setTuition(rs.getInt("s_tuition"));
				sVo.setTime(rs.getString("s_time"));
				sVo.setYear(rs.getString("s_year"));
				sVo.setDate(rs.getDate("s_date"));
				sVo.setDan(rs.getInt("s_dan"));
				sVo.setSclass(rs.getInt("s_class"));
				sVo.setAdd(rs.getString("s_add"));
				sVo.setPname(rs.getString("s_p_name"));
				sVo.setPphone(rs.getString("s_p_phon"));
				sVo.setFilename(rs.getString("filename"));

				list.add(sVo);
			}
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
		return list;
	}

	// �����ͺ��̽� �л� ���̺��� �÷���
	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();
		StringBuffer sql = new StringBuffer();
		sql.append("select * from student");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
		return columnName;
	}

}
