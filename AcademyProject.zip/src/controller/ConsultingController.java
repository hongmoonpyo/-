package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.ConsultingVO;

public class ConsultingController implements Initializable {
	@FXML
	private TableView<ConsultingVO> tableConsulting = new TableView<>();
	@FXML
	private TextField txtLookup;// �˻��Է�
	@FXML
	private Button btnLookup;// �˻� ��ư
	@FXML
	private Button btnEnrollment;// ���
	@FXML
	private TextField txtCName;// �����
	@FXML
	private TextField txtSName;// �л��̸�
	@FXML
	private TextField txtSCode;// �л��ڵ�
	@FXML
	private TextArea txtContents;// ����
	@FXML
	private DatePicker dpDay;// �������
	@FXML
	private Button btnDelete;// ����
	@FXML
	private Button btnReset;//�ʱ�ȭ
	@FXML
	private Button btnEdit;// ����
	@FXML
	private Button btnExit;// ����
	@FXML
	private Button btnTotal;// ��ü

	ObservableList<ConsultingVO> data = FXCollections.observableArrayList();
	ObservableList<ConsultingVO> selectConsulting = null;
	int selectedIndex;
	int scode;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		tableConsulting.setEditable(false);
		TableColumn colCDay = new TableColumn("�������");
		colCDay.setMaxWidth(100);
		colCDay.setStyle("-fx-allignment: CENTER");
		colCDay.setCellValueFactory(new PropertyValueFactory<>("CDay"));
		TableColumn colCName = new TableColumn("�����");
		colCName.setMaxWidth(60);
		colCName.setStyle("-fx-allignment: CENTER");
		colCName.setCellValueFactory(new PropertyValueFactory<>("CName"));
		TableColumn colSName = new TableColumn("�л��̸�");
		colSName.setMaxWidth(60);
		colSName.setStyle("-fx-allignment: CENTER");
		colSName.setCellValueFactory(new PropertyValueFactory<>("SName"));
		TableColumn colSCode = new TableColumn("�л��ڵ�");
		colSCode.setMaxWidth(60);
		colSCode.setStyle("-fx-allignment: CENTER");
		colSCode.setCellValueFactory(new PropertyValueFactory<>("SCode"));
		TableColumn colContents = new TableColumn("��㳻��");
		colContents.setMaxWidth(200);
		colContents.setStyle("-fx-allignment: CENTER");
		colContents.setCellValueFactory(new PropertyValueFactory<>("Contents"));

		tableConsulting.getColumns().addAll(colCDay, colCName, colSName, colSCode, colContents);

		totalList();
		tableConsulting.setItems(data);
//���
		btnEnrollment.setOnAction(event -> {
			try {
				data.removeAll(data);
				ConsultingVO cVo = null;
				ConsultingDAO cDao = new ConsultingDAO();

				cVo = new ConsultingVO();
				cVo.setCDay(Date.valueOf(dpDay.getValue()));
				cVo.setCName(txtCName.getText());
				cVo.setSName(txtSName.getText());
				cVo.setSCode(Integer.parseInt(txtSCode.getText().trim()));
				cVo.setContents(txtContents.getText());

				cDao = new ConsultingDAO();
				cDao.getConsultingregiste(cVo);
				if (cDao != null) {
					totalList();
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("��� ���� �Է�");
					alert.setHeaderText(txtSName.getText() + "��� ������ �߰��Ǿ����ϴ�.");
					alert.setContentText("��� ���� �Է� ����");

					txtCName.clear();
					txtContents.clear();
					txtLookup.clear();
					txtSCode.clear();
					txtSName.clear();
				}

			} catch (Exception e) {
				e.getStackTrace();
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("��� ���� �Է�");
				alert.setHeaderText("��� ������ ��Ȯ�� �Է��ϼ���.");
				alert.setContentText("�������� �����ϼ���.");
				alert.showAndWait();
			}
		});
		btnDelete.setOnAction(event -> handlerBtnDelete(event));// ����
		btnEdit.setOnAction(event -> handlerBtnEdit(event));// ����
		btnExit.setOnAction(event -> handlerBtnExit(event));// ����
		btnReset.setOnAction(event -> handlerBtnReset(event)); //�ʱ�ȭ
		btnTotal.setOnAction(event -> handlerBtnTotal(event));// ��ü
		btnLookup.setOnAction(event -> handlerBtnLookup(event));// �˻�
		tableConsulting.setOnMouseClicked(event -> handlerMouse(event));// ���̺�
	}

	public void handlerBtnReset(ActionEvent event) {
		txtCName.clear();
		txtContents.clear();
		txtLookup.clear();
		txtSCode.clear();
		txtSName.clear();
		
	}

	// ��ü ����Ʈ
	public void totalList() {
		Object[][] totalData;

		ConsultingDAO cDao = new ConsultingDAO();
		ConsultingVO cVo = new ConsultingVO();
		ArrayList<String> title;
		ArrayList<ConsultingVO> list;

		title = cDao.getColumnName();
		int columnCount = title.size();

		list = cDao.getConsultingTotal();
		int rowCount = list.size();
		totalData = new Object[rowCount][columnCount];

		for (int index = 0; index < rowCount; index++) {
			cVo = list.get(index);
			data.add(cVo);
		}
	}

	// ��ü
	public void handlerBtnTotal(ActionEvent event) {
		try {
			data.removeAll(data);
			totalList();
		} catch (Exception e) {
			e.getStackTrace();
		}
	}

	// ���̺�
	public void handlerMouse(MouseEvent event) {
		try {
			if (event.getClickCount() != 2) {


				selectConsulting = tableConsulting.getSelectionModel().getSelectedItems();

				LocalDate date = selectConsulting.get(0).getCDay().toLocalDate();

				txtSName.setText(selectConsulting.get(0).getSName());
				txtSCode.setText(selectConsulting.get(0).getSCode() + "");
				txtCName.setText(selectConsulting.get(0).getCName());
				txtContents.setText(selectConsulting.get(0).getContents());				
				dpDay.setValue(date);
				

				txtSName.setEditable(true);
				txtCName.setEditable(true);
				txtContents.setEditable(true);
				txtSCode.setEditable(true);
				dpDay.setEditable(false);

			}
		} catch (Exception e) {
		}
	}

	// �˻�
	public void handlerBtnLookup(ActionEvent event) {
		ConsultingVO cVo = new ConsultingVO();
		ConsultingDAO cDao = null;

		Object[][] totalDate = null;
		String SearchName = "";
		boolean searchResult = false;
		try {
			SearchName = txtLookup.getText().trim();
			cDao = new ConsultingDAO();
			cVo = cDao.getConsultingcheck(SearchName);

			if (SearchName.equals("")) {
				searchResult = true;
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�л� ���� �˻�");
				alert.setHeaderText("�л� �̸��� �Է��Ͻÿ�");
				alert.setContentText("����");
				alert.showAndWait();
			}
			if (!SearchName.equals("") && (cVo != null)) {
				ArrayList<String> title;
				ArrayList<ConsultingVO> list;

				title = cDao.getColumnName();
				int columnCount = title.size();

				list = cDao.getConsultingTotal();
				int rowCount = list.size();

				totalDate = new Object[rowCount][columnCount];

				if (cVo.getSName().equals(SearchName)) {
					txtLookup.clear();
					data.removeAll(data);
					for (int index = 0; index < rowCount; index++) {
						cVo = list.get(index);
						if (cVo.getSName().equals(SearchName)) {
							data.add(cVo);
							searchResult = true;
							btnTotal.setDisable(false);

						}
					}
				}

				if (!searchResult) {
					txtLookup.clear();
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("�л� ���� �˻�");
					alert.setHeaderText("�л� ����Ʈ�� �����ϴ�.");
					alert.setContentText("�ٽ� �˻��ϼ���.");
					alert.showAndWait();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ����
	public void handlerBtnExit(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/MainView.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scane = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("ü���� ���� ���α׷�");
			mainMtage.setScene(scane);
			Stage oldStage = (Stage) btnExit.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (IOException e) {
			System.out.println("����  " + e);
		}
	}

	// ����
	public void handlerBtnEdit(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/view/EditConsultingView.fxml"));

			Stage dialog = new Stage(StageStyle.UTILITY);
			dialog.initModality(Modality.WINDOW_MODAL);
			dialog.initOwner(btnEnrollment.getScene().getWindow());
			dialog.setTitle("����");
			ConsultingVO cVo = new ConsultingVO();
			Parent parentEdit = (Parent) loader.load();
			ConsultingVO consultingEdit = tableConsulting.getSelectionModel().getSelectedItem();
			selectedIndex = tableConsulting.getSelectionModel().getSelectedIndex();
			
			//�Լ� ����
			DatePicker editday = (DatePicker) parentEdit.lookup("#dpDay");
			TextField editSName = (TextField) parentEdit.lookup("#txtSName");
			TextField editSCode = (TextField) parentEdit.lookup("#txtSCode");
			TextField editCName = (TextField) parentEdit.lookup("#txtCName");
			TextField editContents = (TextField) parentEdit.lookup("#txtContents");
			Button btnEditAdd = (Button) parentEdit.lookup("#btnEditAdd");
			Button btnCancel = (Button) parentEdit.lookup("#btnCancel");
			
			
			editday.setDisable(false);
			editSName.setDisable(false);
			editSCode.setDisable(false);
			editCName.setDisable(false);
			editContents.setDisable(false);
			//���ΰ� ��ȯ
			editday.setValue(dpDay.getValue());
			editSName.setText(consultingEdit.getSName());
			editSCode.setText(consultingEdit.getSCode()+"");
			editCName.setText(consultingEdit.getCName());
			editContents.setText(consultingEdit.getContents());
			
			
			cVo.setCDay(Date.valueOf(editday.getValue()));


			//����Ʈ��Ŀ ����������
			editday.setOnAction(e -> {
				cVo.setCDay(Date.valueOf(editday.getValue()));
			});

			// ������ư ����
			btnEditAdd.setOnAction(e -> {
				ConsultingDAO cDao = null;
				try {
					
					//���� �� ����
					cVo.setCName(editCName.getText());
					cVo.setContents(editContents.getText());
					cVo.setSCode(Integer.parseInt(editSCode.getText().trim()));
					cVo.setSName(editSName.getText());
					dialog.close();

					cDao = new ConsultingDAO();
					cDao.getConsultingUpdate(cVo, cVo.getSCode());

					data.removeAll(data);
					totalList();

				} catch (Exception e1) {
					e1.printStackTrace();
				}
			});

			// ��� ��ư
			btnCancel.setOnAction(e -> {
				dialog.close();
			});

			Scene scene = new Scene(parentEdit);
			dialog.setScene(scene);
			dialog.setResizable(false);
			dialog.show();
		} catch (IOException e) {
			System.out.println(e.toString());
		}
	}

	// ����
	public void handlerBtnDelete(ActionEvent event) {
		ConsultingDAO cDao = null;
		cDao = new ConsultingDAO();

		try {
			cDao.getConsultingDelete(selectConsulting.get(0).getSCode());
			data.removeAll(data);
			totalList();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
