package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.MemberVO;

public class MainController implements Initializable {
	
	@FXML
	private Button btnStudent;
	@FXML
	private Button btnPay;
	@FXML
	private Button btnLogOut;
	@FXML
	private Button btnEmployee;
	@FXML
	private Button btnConsulting;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		btnStudent.setOnAction(event -> hanblerbtnStudentAction(event));
		btnPay.setOnAction(event -> hanblerbtnPayAction(event));
		btnLogOut.setOnAction(event -> hanblerbtnLogOutAction(event));
		btnEmployee.setOnAction(event -> hanblerbtnSEmployeeAction(event));
		btnConsulting.setOnAction(event -> hanblerbtnConsultingAction(event));

	}

	

	// ���
	public void hanblerbtnConsultingAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/ConsultingView.fxml"));
			Parent ConsultingView = (Parent) loader.load();
			Scene scane = new Scene(ConsultingView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("��� ����");
			mainMtage.setScene(scane);
			Stage oldStage = (Stage) btnConsulting.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (IOException e) {
			System.out.println(e);
		}
	}

	// ����
	public void hanblerbtnSEmployeeAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/EployeeView.fxml"));
			Parent EmployeeView = (Parent) loader.load();
			Scene scane = new Scene(EmployeeView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("���� ����");
			mainMtage.setScene(scane);
			Stage oldStage = (Stage) btnEmployee.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (IOException e) {
			System.out.println(e);
		}
	}

	// �α׾ƿ�
	public void hanblerbtnLogOutAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/LoginView.fxml"));
			Parent LoginView = (Parent) loader.load();
			Scene scane = new Scene(LoginView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("�α���");
			mainMtage.setScene(scane);
			Stage oldStage = (Stage) btnLogOut.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (IOException e) {
			System.out.println(e);
		}
	}

	// ����
	public void hanblerbtnPayAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/PayView.fxml"));
			Parent PayView = (Parent) loader.load();
			Scene scane = new Scene(PayView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("����");
			mainMtage.setScene(scane);
			Stage oldStage = (Stage) btnPay.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// �л�
	public void hanblerbtnStudentAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/StrudentView.fxml"));
			Parent StudentView = (Parent) loader.load();
			Scene scane = new Scene(StudentView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("�л� ����");
			mainMtage.setScene(scane);
			Stage oldStage = (Stage) btnStudent.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
